package com.lagou.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.permission.FsPermission;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class HdfsClient {

    private FileSystem fileSystem =null;
    private Configuration conf =null;

    @Before
    public void init() throws URISyntaxException, IOException, InterruptedException {
        conf = new Configuration();
        conf.set("dfs.client.use.datanode.hostname","true");
        fileSystem = FileSystem.get(new URI("hdfs://teacher1:9000"),conf,"teacher");

    }
    @After
    public void after() throws IOException {
        fileSystem.close();
    }

    @Test
    public void testCopyFromLocal() {
        try {
            fileSystem.copyFromLocalFile(new Path("c:/lagou/teacher.txt"),new Path("/lagou/teacher1.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void  testMkdir() throws IOException {
        fileSystem.mkdirs(new Path("/lagou/lagou_lecture"),new FsPermission("600"));
    }
}
