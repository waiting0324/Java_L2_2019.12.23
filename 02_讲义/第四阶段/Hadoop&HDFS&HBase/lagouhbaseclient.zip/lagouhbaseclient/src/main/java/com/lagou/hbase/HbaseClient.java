package com.lagou.hbase;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;

public class HbaseClient {


    public static Configuration conf;

    static {
        conf = HBaseConfiguration.create();
        conf.set("hbase.zookeeper.quorum","teacher2");
        conf.set("hbase.zookeeper.property.clientPort","2181");

    }

    public static void createTable() throws IOException {

        Connection conn = ConnectionFactory.createConnection(conf);

        HBaseAdmin admin =  (HBaseAdmin) conn.getAdmin();

        //创建表的描述器
        HTableDescriptor teacher = new HTableDescriptor(TableName.valueOf("teacher"));

        //设置列族
        teacher.addFamily(new HColumnDescriptor("info"));
        teacher.addFamily(new HColumnDescriptor("other"));

        admin.createTable(teacher);

        System.out.println("create table success");


    }

    public static void putData() throws IOException {
        Connection conn = ConnectionFactory.createConnection(conf);

        HBaseAdmin admin =  (HBaseAdmin) conn.getAdmin();

        Table t = conn.getTable(TableName.valueOf("teacher"));

        Put put = new Put(Bytes.toBytes("rk1"));

        put.addColumn(Bytes.toBytes("info"),Bytes.toBytes("addr"),Bytes.toBytes("shanghai"));
        put.addColumn(Bytes.toBytes("other"),Bytes.toBytes("desc"),Bytes.toBytes("xxxxxxxxxxx"));

        t.put(put);

        t.close();
        System.out.println("insert success");



    }

    public static void main(String[] args) throws IOException {
//        createTable();
        putData();
    }

}
