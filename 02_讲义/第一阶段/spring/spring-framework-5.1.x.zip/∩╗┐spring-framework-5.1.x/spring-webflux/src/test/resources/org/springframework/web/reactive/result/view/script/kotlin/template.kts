import org.springframework.web.reactive.result.view.script.*

"""${include("header") }
<p>${i18n("hello")} $foo</p>
${include("footer")}"""
