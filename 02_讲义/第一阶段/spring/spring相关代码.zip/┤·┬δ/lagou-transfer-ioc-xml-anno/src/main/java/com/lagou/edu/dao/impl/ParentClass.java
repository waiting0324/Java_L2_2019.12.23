package com.lagou.edu.dao.impl;

/**
 * @author 应癫
 */
public class ParentClass {
}
